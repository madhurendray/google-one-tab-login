<?php
    // use sessions, to show the login prompt only if the user is not logged-in
    session_start();
 
    // paste google client ID and client secret keys
    $google_oauth_client_id = "777854806822-h19kcgkdfg58a7586h8tgpbacot72n7h.apps.googleusercontent.com";
    $google_oauth_client_secret = "";
?>

<!-- check if the user is not logged in -->
<?php if (!isset($_SESSION["user"])): ?>
 
    <!-- display the login prompt -->
    <script src="https://accounts.google.com/gsi/client" async defer></script>
    <div id="g_id_onload"
        data-client_id="<?php echo $google_oauth_client_id; ?>"
        data-context="signin"
        data-callback="googleLoginEndpoint"
        data-close_on_tap_outside="false">
    </div>
     
<?php endif; ?>

<script>
    // callback function that will be called when the user is successfully logged-in with Google
    function googleLoginEndpoint(googleUser) {
        // get user information from Google
        console.log(googleUser);
 
        // send an AJAX request to register the user in your website
        var ajax = new XMLHttpRequest();
 
        // path of server file
        ajax.open("POST", "google-sign-in.php", true);
 
        // callback when the status of AJAX is changed
        ajax.onreadystatechange = function () {
 
            // when the request is completed
            if (this.readyState == 4) {
 
                // when the response is okay
                if (this.status == 200) {
                    console.log(this.responseText);
                }
 
                // if there is any server error
                if (this.status == 500) {
                    console.log(this.responseText);
                }
            }
        };
 
        // send google credentials in the AJAX request
        var formData = new FormData();
        formData.append("id_token", googleUser.credential);
        ajax.send(formData);
    }
</script>
